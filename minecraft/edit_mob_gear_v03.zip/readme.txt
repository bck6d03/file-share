v1
暫時設定只能修改骷髏的裝備

#把玩家副手物品記錄在 editmobgear:temp playerhand
#根據物品種類定義位置：0=主手, 1=副手, 2=頭, 3=身, 4=腿, 5=鞋
#發射射線，如果找到生物：
#1:把生物裝備位置的物品記錄在 editmobgear:temp mobhand
#2:把生物裝備位置的物品轉換成 editmobgear:temp playerhand
#如果成功找到生物：把玩家副手物品轉換成 editmobgear:temp mobhand

v2
改用shift發射raycat進行修改，另外修復了護甲裝備的BUG
問題:無法把護甲裝備拿下來，只能用其他裝備替換


v3
新方案：
主手拿著工具才能使用
右鍵：切換工具模式（主手、副手、裝甲）
Shift：
＞主手：把副手物品和對象的主手物品交換
＞副手：把副手物品和對象的副手物品交換
＞裝甲：把副手的裝甲物品裝備到對象身上，如果副手不是裝甲物品，根據「頭、身、腿、鞋」的次序得到那些位置的裝備

#/give @s minecraft:warped_fungus_on_a_stick{display:{Name:'[{"text":"生物裝備替換工具:主手","italic":false}]'}}
#/give @s minecraft:warped_fungus_on_a_stick{display:{Name:'[{"text":"生物裝備替換工具:副手","italic":false}]'}}
#/give @s minecraft:warped_fungus_on_a_stick{display:{Name:'[{"text":"生物裝備替換工具:裝甲","italic":false}]'}}








