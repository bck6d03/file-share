
	// Fraxy Custom Sprite

	// A line beginning in ; or // is a line comment.
	// Line comments can appear only at the beginning of a line.

	// "buffer", bufID, "image", "alpha-image"
	// Creates buffer and loads images.

"Buffer", 0, "sample.bmp", "sample_a.bmp"

	// "select", bufID
	// Selects a buffer.

"Select", 0

	// "index", spriteIndex
	// Sets the current sprite index.

"Index", 0

	// Sprite data
	// PosX, PosY, SizeX, SizeY, (CenterX), (CenterY)
	// CenterX and Y is optional.

	0, 0, 32, 32
	56, 24, 32, 32

"Index", 10

	0, 80, 16, 16
	16, 80, 16, 16
	32, 80, 16, 16
	48, 80, 16, 16
	64, 80, 16, 16
	80, 80, 16, 16

"Index", 20

	0, 96, 16, 16
	16, 96, 16, 16
	32, 96, 16, 16
	48, 96, 16, 16
	64, 96, 16, 16
	80, 96, 16, 16

"Index", 30

	0, 112, 16, 16
	16, 112, 16, 16
	32, 112, 16, 16
	48, 112, 16, 16
	64, 112, 16, 16
	80, 112, 16, 16

"Index", 40

	96, 80, 16, 16
	112, 80, 16, 16
	96, 96, 16, 16
	112, 96, 16, 16
	96, 112, 16, 16
	112, 112, 16, 16
