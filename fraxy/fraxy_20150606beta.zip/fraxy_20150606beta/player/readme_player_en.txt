// Setting of players graphic and animation

// Define of Player file(*.fpl) and image file.
"FRAXY_PLAYER","Name of this set","Image file *.bmp/jpg/mag","Alpha image file *.bmp/jpg/mag"

// Preview image setting
// Blend mode 7(alpha blending) can use in preview. 
// Please prepare alpha mask picture next to in the same image.
// When not understanding well, please see a sample.
"PREVIEW", base x, base y, size x, size y, blend mode

// Player image setting
"PLAYERIMAGE", base x, base y, size x, size y, center y, rolling animation pattern number

// Destroy pattern setting
// 0 : normal
// 1 : blue flash
"PLAYERDESTROY", destroy pattern

// Booster image setting
// IMAGE1 : Fire (This has to prepare the same number as a roll animation.)
// IMAGE2 : Light
// IMAGE3 : Particle
// FLAG : Presence of a booster of each way
// DISTANCE : Distance of a booster position of each way (256=1dot /1024=4dot)
"BOOSTIMAGE1", base x, base y, size x, size y
"BOOSTIMAGE2", base x, base y, size x, size y
"BOOSTIMAGE3", base x, base y, size x, size y
"BOOSTFLAG", 0, TR, R, BR, B, BL, L, TL
"BOOSTDISTANCE", 0, TR, R, BR, B, BL, L, TL

// Shield image setting
// IMAGE1 : drawn on player.
// IMAGE2 : drawn under player.
// option : 1=adjust player angle
"SHIELDIMAGE1", base x, base y, size x, size y, center y, blend mode, blend rate, animation number, option
"SHIELDIMAGE2", base x, base y, size x, size y, center y, blend mode, blend rate, animation number, option
