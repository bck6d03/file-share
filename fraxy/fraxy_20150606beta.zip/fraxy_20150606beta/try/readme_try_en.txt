---------------------------
   FRAXY Try script
    English manual
                   by mon
---------------------------

-- Try script notes

    * Function and Variable operation can describe only one for one line.

    * The line where / and ; are in the head is ignored as a comment.

    * When putting // or ; in the rear of function and variable operation, it'll be a comment even at the end of the line.

    * A character string and function are enclosed with "".

    * File searches start at try folder.
      When not found, It searches from each file folder.

    * The error checking is very loose.
      So an critical error may occur by a description mistake.

    * It's possible to calculate in the parameter.
      But, a calculation order by an operator is ignored.
      ex) 
          "WAIT",1+2*3   -> "WAIT",9
          "WAIT",1+(2*3) -> "WAIT",7

    * A character string can be combined.
      ex)
          "MESSAGE","test"+123+"sample",...  -> "MESSAGE","test123sample",...
          "MESSAGE","Player X = "+_px,...    -> "MESSAGE","Player X = 200",...
          "MESSAGE","Player X+Y = "+(_px+_py),... -> "MESSAGE","Player X+Y = 300",...

    * When " used in the character string, the character string cannot be output well.


-- Processing

    It's processed in turn from the top.
    Almost all of function doesn't return to a main loop of a game and processes it.
    But, the number of times which can be processed together is restricted to 1024 times
    because there is danger of freeze.

    It can't be recommended because it's very slow not to return to a main loop and to continue the processing.
    So please return it to a main loop using following function.

    "END"
    "LIMIT"
    "WAIT"
    "BGMSTOP"
    "SESTOP"
    "CHOICES"
    "GAMEOVER"


-- Variable

    A variable is made automatically at the time of the first time reference.

    A variable can use the following style.

    int     (-2147486948 ~ 2147483647)
    double  (up to about 15 digits)
    str     (maximum size: 65535)

    The character a variable name is to 32 character and which can be used is the following.

    Alphabet    a ~ z  A ~ Z
    Number      0 ~ 9
    Under bar   _

    When the character excluding this is used, it doesn't operate normally maybe.
    Moreover, please don't use a number for the first character.

    The alphabet doesn't have the distinction between the capital letter and the small letter.
    For instance, Pos_X and pos_x are judged to be the same variable.

    The variable of the same name as the math function cannot be used.

    The following variables are defined beforehand. 
    Please use it to refer to the value basically. 

    _null        (int) It's insignificant in particular
    _stat        (int) Value of system return
    _cnt         (int) Loop counter (counts start at 0)
    _time        (int) Value of timer
    _winx        (int) Current window width (X)
    _winy        (int) Current window height (Y)

    _px          (int) Absolute coordinate X of player
    _py          (int) Absolute coordinate Y of player
    _pscore      (int) Player score
    _pleft       (int) Player left
    _penergy     (int) Player energy
    _penergymax  (int) Player energy maximum
    _pstock      (int) Player energy stock
    _pstockmax   (int) Player energy stock maximum

    _killcore    (int) Kill count (Core)
    _killparts   (int) Kill count (Parts)

    _global1     (int) Global variable 1
    _global2     (int) Global variable 2
    _global3     (int) Global variable 3
    _global4     (int) Global variable 4
    _global5     (int) Global variable 5
    _global6     (int) Global variable 6
    _global7     (int) Global variable 7
    _global8     (int) Global variable 8


-- Variable operation

    Variable operation is described by the following shape basically.

    (target var)  (operator)  (expression and value)
    test          =           1

    The operator of variable operation is different from an operator of an expression.
    The operator for which below can be used by variable operation.

    =      Substitution        test = 1
    ==     Substitution        test == 1
    +      Addition            test + 5
    -      Subtraction         test - 5
    +=     Addition            test += 5
    -=     Subtraction         test -= (3+2)

    Below is a unique operator.

    +      Inclement           test +     //  Add 1 to test
    ++     Inclement           test ++    //  Add 1 to test
    -      Declement           test -     //  Subtract 1 from test
    --     Declement           test --    //  Subtract 1 from test
    =      Reset               test =     //  This is same as test=0
    ==     Reset               test ==    //  This is same as test=0


-- Math function

    The following math function can be used in this script.

    sin      sin(value)   [value (int): 0~4095] [return (int): -4096~4096]
             Sin value.

    cos      cos(value)   [value (int): 0~4095] [return (int): -4096~4096]
             Cos value.

    limit    limit(value,min,max)    [value (int/double)] [min (int/double)] [max (int/double)] [return (int/double)]
             Return the value from min to max.
             ex)
             limit(abc, -10, 20)

    abs      abs(value)    [value (int/double)] [return (int/double)]
             Absolute value.
             ex)
             abs(5)     ->  5   (int)
             abs(-5)    ->  5   (int)
             abs(-5.0)  ->  5.0 (double)

    sqrt     sqrt(value)    [value (int/double)] [return (double)]
             Square root.

    rand     rand(value)    [value (int): 1~] [return (int): 0~(value-1)]
             Random number.

    int      int(value)    [value (int/double/str)] [return (int)]
             Convert to int type.

    double   double(abc)    [value (int/double/str)] [return (double)]
             Convert to double type.

    str      str(abc)    [value (int/double/str)] [return (str)]
             Convert to str type.

    strf     strf("format",value)    ["format" (str)] [value (int/double/str)] [return (str)]
             String format.
             The format is same as sprintf of C, but input value is only one.
             ex)
             abc = 123.4567
             strf("%d",abc)     ->  123
             strf("%0.2f",abc)  ->  123.45
             strf("%x",abc)     ->  7b
             strf("%8X",abc)    ->        7B
             strf("%08X",abc)   ->  0000007B

    getpath  getpath("str",type)    ["str" (str)] [type (int): 0~] [return (str)]
             Convert the file path string.
             type : 
                 &1      The file name except for the extension.
                 &2      Only an extension. (.???)
                 &8      Directory information is taken.
                 &16     A character string is changed to lowercase.
                 &32     Only directory information.
             ex)
             file = "C:\temp\aBc.txt"
             getpath(file,2)  ->  ".txt"
             getpath(file,8)  ->  "aBc.txt"
             getpath(file,24) ->  "abc.txt"

    strlen   strlen(target)    [target (int/double/str)] [return (int)]
             String length.
             When parameter type is int or double, that returns the number of digits.
             ex)
             strlen(100)      ->  3
             strlen("abcde")  ->  5

    peek     peek(target,offset)    [target (str)] [offset (int): 0~] [return (int): 0~255]
             Read 1byte.
             ex)
             peek(abc,0)

    chr      chr(code)    [code (int): 0~255] [return (str)]
             Converts character code to string.
             ex)
             strlen(65)  ->  A
             strlen(66)  ->  B
             strlen(97)  ->  a
             strlen(48)  ->  0
             strlen(57)  ->  9

    getinfo  chr(type,param)    [type (int)] [param (int)] [return (int)]
             This is same as "GETINFO".


-- Operator

    The following operator can be used in this script.

    =     equal
    ==    equal
    !     not
    >     greater than
    <     less than
    >=    greater than or equal to
    <=    less than or equal to
    +     add
    -     subtract
    *     multiply
    /     divide
    %     surplus
    &     and
    |     or
    ^     xor
    <<    bit shift L
    >>    bit shift R


-- Label

    A label is the mark to jump by "GOTO" and "GOSUB".
    When describing a label, please be sure to put * like an example.
    When designating a label as a parameter, "" is needed.
    But the label isn't supposed to put "".

      ex)
          "GOSUB", "*TEST_LABEL"
          "END"
          *TEST_LABEL
          // Processing of a jump destination.
          "RETURN"

    Label designation has 2 kinds, a normal-label and a multi-label.

    Normal-label (jump destination is only one)
      ex) "GOSUB", "*TEST_LABEL"

    Multi-label  (jump destination is plural)
      ex) "GOSUB", "*TEST_LABEL"+abc
          In this case, a jump destination is changed by value of variable abc.
          *TEST_LABEL0
          *TEST_LABEL1
          *TEST_LABEL2...
          When a label doesn't exist, jump isn't performed.
          Exception: When a label isn't found by "TIMEREND" and "PLAYERDESTROYED", an error is returned and processing of a try is stopped.


-- For parameter of function

    str   Inputs the character string.
    int   Inputs the value or the variable.
    var   Inputs the variable.
          When the variable is omitted, _stat is used.

    &1, &2 and something described are to add its price to the other prices,
    and it's possible to soak a parameter in more than one parameter.
    For example when soaking in &1, &2 and &4, 7 is designated.


-- Preprocessor function

    A preprocessor function is executed before a convert of a script.

  #include "str1"
        Combine a file in its line.
        An extension of a file doesn't mind everything.
        It's necessary to be a form of a try script.
        A definition of "FRAXY_TRY" is ignored.

        str1    file name


-- Functions
    
  "FRAXY_TRY","str1",(int2)
        Definition of Try.
        Please put it first.

        str1    Try's name
        int2    Try option
                &1      Start without player (When set this option, use "SETPLAYER" to create player)


  "BGLOAD","str1",int2,int3,int4,int5,int6,(int7),(int8)
        Loads the background image.
        Three images can be registered in one background set. (ID-0 ~ ID-2)
        ID0 is drawn first.
        When the background option is set to simple, drawn only ID-0.
        The size of the image doesn't care about any size.
        However, it becomes unnatural if it doesn't connect it though
        an upper and lower right and left makes it scroll.
        When omitting a base point, the center of the image is set as that.

        str1    Image file name (*.bmp *.jpg *.mag)
        int2    Background set to load (1~4)
        int3    ID- (0~2)
        int4    Z value for scroll (500~4000 or -1)
                Z value of the player is 1000.
                It is judged a position that is lower than the player any more.
                When -1 is specified, it doesn't scroll.

        int5    Draw blend mode (3~6)
                3       Translucent
                4       Translucent with black(r=0,g=0,b=0) disregard
                5       Addition
                6       Subtraction

        int6    Draw blend rate (0~255)

        (int7)  Base point X of image
        (int8)  Base point Y of image


  "BGCHANGE",int1
        Changes the background set.

        int1    Background set (0~4)
                0       Default
                1~4     Loaded background set


  "BGSCROLL",int1,int2,int3,int4
        Set a background scroll.

        int1    Scroll speed
        int2    Fade value of scroll speed (1~)
        int3    Scroll angle (0~4095)
        int4    Fade value of scroll angle (1~)


  "BGFADE",int1,int2,int3
        Set a background fade speed.

        int1    Fade speed of ID-0 (1~255)
        int2    Fade speed of ID-1 (1~255)
        int3    Fade speed of ID-2 (1~255)


  "BGBASEPOS",int1,int2,int3,int4
        Set a background base point.

        int1    Background set (1~4)
        int2    ID- (0~2)
        int3    base point X
        int4    base point Y


  "BGMOVE",int1,int2,int3,int4,int5,int6
        Set a movement in a background base point.

        int1    Background set (1~4)
        int2    ID- (0~2)
        int3    Target base point X
        int4    Target base point Y
        int3    Speed
        int4    Option
                0        None
                1        Move smoothly


  "WAIT",int1
        The script processing is stopped during the specified frame value.
        One second is 30~40 frame.

        int1    Wait value


  "MESSAGE","str1",int2,int3,int4,int5
        Sends message to the system message frame.

        str1    Message
        int2    Color R
        int3    Color G
        int4    Color B
        int5    Blink flag (0~1)
                0        Off
                1        On


  "TIMER",int1
        Timer setting.

        int1    Set value
                -1      Invalidates the timer
                1~      The specified time(second) is set to the timer.


  "TIMERADD",int1
        Adds to the timer.

        int1    Add time(second)


  "TIMEREND",int1,"label2",int3
        Processing when timer ends.
        Uses a value that returned by "ADDSUBSCRIPT" to ScriptID.
        If ScriptID is omitted or 0, that will be 0. (0=MainScript)

        int1      Processing
                  0       Game over
                  1       Clear
                  2       Jump to label (goto)
                  3       Jump to label (gosub)

        "label2"  Label name
        int3      ScriptID


  "START"
        Starts the count of the timer.


  "STOP"
        Stops the count of the timer.


  "POS",int1,int2
        Base point setting of generation.
        This becomes a base point when generating it with "CREATE2" and "ITEM2".
        This is specified by the absolute coordinate.

        int1    Pos X
        int2    Pos Y


  "COLOR",int1,int2,int3
        Sets the color used by each function.
        This color is used in "MESSAGE", "EXMESSAGE", "FLASH" and "INVERT".
        int1    R (Red)
        int2    G (Green)
        int3    B (Blue)


  "QUAKE",int1
        Quake effect.
        int1    Frame value


  "SHAKE",int1
        Shake effect.
        int1    Frame value


  "FLASH",int1,int2,int3,int4,int5
        Screen effect.
        This function needs the color setting by "COLOR".
        int1    Fade in frame value
        int2    Hold frame value
        int3    Fade out frame value
        int4    Blend rate (0~255)
        int5    Blend mode (3~6)
                3       Translucent
                4       Translucent with black(r=0,g=0,b=0) disregard
                5       Addition
                6       Subtraction


  "BLUR",int1,int2,int3,int4,int5
        Blur effect.
        int1    Hold frame value
        int2    Max frame value
        int3    Zoom rate (1~32)
        int4    Blend rate (0~255)
        int5    Searing images blend rate (-96~96)


  "INVERT",int1,int2,int3,int4,int5
        Invert effect.
        This function needs the color setting by "COLOR".
        It's usually set as follows.
        "COLOR",255,255,255
        int1    Fade in frame value
        int2    Hold frame value
        int3    Fade out frame value
        int4    Blend rate (0~255)
        int5    Blend mode (3~6)
                3       Translucent
                4       Translucent with black(r=0,g=0,b=0) disregard
                5       Addition
                6       Subtraction


  "GRAYSCALE",int1,int2,int3,int4,int5
        Grayscale effect.
        int1    Fade in frame value
        int2    Hold frame value
        int3    Fade out frame value
        int4    Blend rate (0~255)
        int5    Blend mode (3~6)
                3       Translucent
                4       Translucent with black(r=0,g=0,b=0) disregard
                5       Addition
                6       Subtraction


  "MOSAIC",int1,int2,int3,int4,int5
        Mosaic effect.
        When the block size is 0, applies the window size.
        int1    Fade in frame value
        int2    Hold frame value
        int3    Fade out frame value
        int4    Flag (0~2)
                0       Disable mosaic
                1       Enable halftone mosaic
                2       Enable mosaic

        int5    Block size X (0 or 1~)
        int6    Block size Y (0 or 1~)


  "FONT","str1",int2,int3
        Sets the font used in "EXMESSAGE". 
        str1    Font name
                When omitting it, default font is specified.

        int2    Font size
        int3    Style
                0       Normal
                &1      Bold
                &2      Italic


  "EXMESSAGE","str1",int2,int3,int4,int5,int6,int7
        Shows the message.
        The color and the font change by other functions.
        If the function succeeds, the ID of message returns to _stat.
        If the function fails, -1 returns to _stat.
        str1    Message
        int2    Align flag (0~15)
                0       Left / Top
                &1      Center
                &2      Right
                &4      Middle
                &8      Bottom

        int3    Base Position based on window (0~8)
                ---------
                |0  1  2|
                |3  4  5|
                |6  7  8|
                ---------

        int4    Positional correction X (dot)
        int5    Positional correction Y (dot)
        int6    Display time (frame)
                >=0     Specified frame value
                -1      infinite

        int7    Option flag
                0       Normal
                &1      Blink
                &2      Open face
                &4      Each one character
                &8      Fade in


  "DELEXMESSAGE",int1,int2
        Deletes the message that made by "EXMESSAGE".

        int1    ID of message
        int2    Delete type (0~1)
                0       Instantly
                1       Fadeout


  "EBULLETCOLOR",int1,int2,int3,int4
        Changes the color tone of enemy bullet.
        Attention: This function is very slow.
        Also, when the user is setting the monochrome,
        there is a thing that doesn't become a tone at which it aims according to the
        difference with the default color either.

        int1    Change flag
                0       changes the color tone with specified HSL.
                1       Return to user setting
                &2      Disable fade

        int2    H Hue
        int3    S Saturation
        int4    L Lightness


  "CREATE","str1",int2,int3,int4,int5,int6
        Enemy generation based on player position.
        If the function succeeds, the ID of core parts returns to _stat.
        If the function fails, -1 returns to _stat.

        str1    File name of enemy
        int2    Direction of initial (0~4095)
        int3    Direction of generation position (0~4095)
        int4    Distance of generation position (0~)(dot)
                About 500 is a just good distance.

        int5    Enemy rank (0~100)
                0       Based on a usual rank rise
                1~100   Specified rank

        int6    Generation message flag
                0       Don't show message
                1       Show message


  "CREATE2","str1",int2,int3,int4,int5,int6
        Enemy generation with absolute coordinate.
        The position is corrected with int3 and int4 based on the base point set by "POS".
        If the function succeeds, the ID of core parts returns to _stat.
        If the function fails, -1 returns to _stat.

        str1    File name of enemy
        int2    Direction of initial (0~4095)
        int3    Positional correction X
        int4    Positional correction Y
        int5    Enemy rank (0~100)
                0       Based on a usual rank rise
                1~100   Specified rank

        int6    Generation message flag
                0       Don't show message
                1       Show message


  "BUFFER",int1,int2
        Make the buffer to read an enemy file.
        The enemy file loaded in this buffer can be generated at higher speed than usual.
        When 32768 byte and number of buffers were set as 10,
        Even can load 10(ID0~9) files up to about 32 KB.

        int1    The size per one buffer (byte)
        int2    Number of buffers


  "LOAD","str1",int2
        Load an enemy file to a buffer.
        When you want generate enemy from a buffer,
        input "*0" to load from ID0.
        Equally you want load from ID1, input "*1".

        str1    File name of enemy
        int2    Buffer ID to load


  "ITEM",int1,int2,int3
        Item generation based on player position.

        int1    Item type
                -4      Highest item
                -3      High item
                -2      Middle item
                -1      Lowest item
                0       Normal item
                1       Constructed item

        int2    Direction of generation position (0~4095)
        int3    Distance of generation position (0~)(dot)


  "ITEM2",int1,int2,int3
        Item generation with absolute coordinate.
        The position is corrected with int2 and int3 based on the base point set by "POS".

        int1    Item type
                -4      Highest item
                -3      High item
                -2      Middle item
                -1      Lowest item
                0       Normal item
                1       Constructed item

        int2    Positional correction X
        int3    Positional correction Y


  "ITEMCONSTRUCT",int1,int2...
        Configuration change of an item.
        Please set item ID of the number set to int1 to int2~8.
        int1    Item count (1~7)
        int2~8  Item ID (1~14)
                1       Max energy up
                2       Regenerate up
                3       Equip level up
                4       Over soll
                5       Full charge
                6       Max energy and regenerate up
                7       Bullet type level up
                8       Blaster type level up
                9       Support type level up
                10      All equip level up
                11      All equip level down
                12      Extend
                13      (!)
                14      (!?)

  "ITEMSCROLL",int1,int2,int3,int4
       Set a items scroll.

        int1    Scroll speed
        int2    Fade value of scroll speed (1~)
        int3    Scroll angle (0~4095)
        int4    Fade value of scroll angle (1~)


  "LIMIT",int1,int2
        Script stop by number of enemies.
        The script is stopped until becoming below the specified number of limitations.
        When -1 is specified, the limitation is invalidated.

        int1    Limitation of total of enemy (number of cores)
        int2    Limitation of number of parts


  "RANK",int1
        The enemy's base rank setting.

        int1    Base rank
                -1      Rank of free play setting
                1~100   Specified rank


  "RANKRATE",int1
        The rank rate of increase setting by enemy destruction.
        100 is specified in the initial state.

        int1    Increase rate (0~1000)(%)


  "REPEAT",int1
  "LOOP"
  "EXITLOOP"
  "CONTINUE"
        Loop processing.
        The loop number of times repeats processing from "REPEAT" to "LOOP".
        Multiloop is possible up to 16.
        When the loop number of times is 0, processing from "REPEAT" to "LOOP" is ignored.
        When it is -1, that loops infinitely.
        "CONTINUE" returns to "REPEAT" and continues a loop.
        "EXITLOOP" exits from a loop.

        int1    The loop number of times



  "BGMPLAY","str1",int2,int3
        Load and plays BGM.
        Already when playing, the file cannot be loaded.

        str1    BGM file name (*.mid *.mp3)
        int2    Loop flag
                0       No loop
                1       Infinite loop
        int3    Message of BGM file name
                0       Hide
                1       Show


  "BGMSTOP"
        Stops the playing bgm.
        Please stop the playing BGM before loading another BGM.


  "SEPLAY","str1",int2,int3
        Load and plays sound.
        Already when playing, the file cannot be loaded.

        str1    Sound file name (*.wav)
        int2    Loop flag
                0       No loop
                1       Infinite loop

        int3    Play priority level
                0~


  "SESTOP"
        Stops the playing sound.
        Please stop the playing sound before loading another sound.


  "POWERUP",int1,int2
        Changes the armament level of player.
        The value for which all armaments are specified increases and decreases.

        int1    Level change value
        int2    Message and sound flag
                0       Off
                1       On


  "FULLENERGY",int1
        Recovers the energy of the player.

        int1    Message and sound flag
                0       Off
                1       On


  "SETPLAYER",int1
        When having begun without a player, create a player by this function.

        int1    Option
                -1      Delete player
                0       Create player
                1       Create player (reserve)


  "DESTROYPLAYER",int1
        Deletes/Removes player.

        int1    Effect type
                -1      None
                0       Explosion
                1       Phase in (this effect is same as "SETPLAYER",-1)


  "PLAYERSHIP",int1,int2,int3,int4,int5,int6
        Changes the player type and weapons.
        When changing the player type, it's recommended to do just after the try starting.
        When the weapon was changed, the level is set as 1.
        When setting None as main slot, Bullet is chosen.
        int1    Player type
                -1      No change
                0       Standard
                1       Attacker
                2       Tanker
                3       Quicker
                4       BulletHell
                5       Deadlocker

        int2    Main slot
        int3~6  Sub slot 1~4
                -1      No change
                0       None
                1       Bullet
                2       Wide bullet
                3       Vulcan
                4       Stun bullet
                5       Blaster
                6       Multi blaster
                7       Stun blaster
                8       Charge blaster PT
                9       Charge blaster QT
                10      Over loader
                11      Temporal shield
                12      Blur decoy
                13      Soll diffuser
                14      Soll activator
                15      Absolute shield


  "PLAYERLEFT",int1
        Changes the player left.
        int1    Player left


  "PLAYERSCORE",int1
        Changes the player score.
        int1    Player score


  "PLAYERFLAG",int1,int2,int3
        Changes the player flag.
        int1    Show flag
                -1      No change
                0       Hide
                1       Show

        int2    Invincible flag
                -1      No change
                0       OFF
                1       ON

        int3    Control flag
                -1      No change
                0       Impossible
                1       Possible


  "PLAYERANGLE",int1,int2
        Changes the player angle and flag.
        int1    Player angle
        int2    Player angle fixed flag
                -1      No change
                0       Disable
                1       Enable


  "PLAYERSTATUS",int1,int2
        Changes the player energy level and regeneration level.
        int1    Fluctuation value of the energy level
        int2    Fluctuation value of the regeneration level


  "PLAYERRESPAWN",int1,int2,int3,int4
        Changes the player respawn position.
        int1    Flag
                0       Default
                1       Absolute position (X=int2, Y=int3)
                2       Player position

        int2    Param1
        int3    Param2
        int4    Effect type
                0       Default
                1       Phase out


  "SCORERATE",int1
        Changes the score rate.
        int1    Score rate


  "SCORESYSTEM",int1,int2
        Changes the score rate draw flag and the scoring system.
        int1    Score rate draw
                -1      No change
                0       Hide
                1       Chain rate
                2       Score

        int2    scoring system
                0       Disable the chain rate
                1       Rate by chain destroy
                2       Rate by "SCORERATE"

  "AREALIMIT",int1,int2,int3,int4,int5,int6
        Restrict the movable area of player.
        The contents of restrict area parameter change by the shape.
        int1    Restrict area shape
                0       Remove the restrict
                1       Circle
                2       Square

        int2    Draw option of restrict area
                &1       Draw limit line
                &2       Draw an outside darkly (square type only)

        int3    Restrict area parameter1
                Circle  Size
                Square  Width

        int4    Restrict area parameter2
                Square  Height

        int5    Base point X
        int6    Base point Y


  "AREAFIXED",int1
        Set the area fixed mode.
        int1    area fixed mode
                0       Disable
                1       Enable


  "INTERFACE",int1
        Operation of interface.
        int1    Show flag
                -1      Hide without fade
                0       Hide with fade-out
                1       Show with fade-in


  "CLEARENEMY",int1
        Deletes all enemies.
        The enemy disappears the collision judgment,
        and is not counted to the limitation of the total of the enemy and the limitation of the 
        number of parts such as "LIMIT". 

        int1    Delete type
                0       Destruction
                1       Phase in


  "DESTROYENEMY",int1,int2
        Deletes the specified enemy.
        Target ID uses ID returned by "CREATE" and "CREATE2". 
        The deletion fails when targets ID are not the core parts.

        int1    Target ID
        int2    Delete type
                0       Destruction
                1       Phase in


  "END"
        Ends the Try.
        Please end with this function.


  "IF",int1
  "ENDIF"
        Judges the specified expression.

        int1    Judged expression or value

        Please use it together with "ENDIF".
        If the expression consists, the following line is executed as it is. 
        Processing is disregarded as for the line of set "ENDIF" when not consisting.
        Multiple "IF" is also possible.

        The judgment is judged by the value of the result of the expression. 
        It doesn't consist if the result is 0,
        and it is judged that it consists if other. 

        ex)
        "IF", test=5
        If test is 5, 1 is output and 'Consist'.
        If test is numbers except 5, 0 is output and 'Do not consist'.

        "IF", 5
        5 is output and 'Consist'.


  "ELSE"
        Processing when expression doesn't consist.
        It uses it to put processing when not consisting of "IF".

        ex)
        "IF", test < 5
                "MESSAGE","test < 5 : Consist",255,255,255,0
        "ELSE"
                "MESSAGE","test < 5 : Do not consist",255,255,255,0
        "ENDIF"


  "GOTO","label1"
        Jumps to the specified label.

        "label1"    Label name

        Please put the sign such as * on the head about the label name so as not to 
        overlap with the variable. 
        When two or more labels of this name exist, it becomes effective above.
        Please see the sample in detail. (sample goto gosub.ftd)


  "GOSUB","label1"
        Sub jumps to the specified label.
        The subjump memorizes the line before it jumps.
        So it is possible to return by "RETURN".
        Please return by "RETURN" when you finish processing in the jump destination.

        It is possible to subjump in the multiple. 
        However, because the loop instruction is shared with the storage area, it 
        becomes it up to total of 16.


  "RETURN"
        Returns to the line before it subjumps.


  "GETINFO",int1,int2,(var3)
        Gets information and returns it to _stat.
        When the variable is specified for var3, returns to the variable.

        int1    Type of information
        int2    Parameter option

        Please refer to doc_getinfo_eng.txt for details of type and parameter.

        Please use identification ID of the enemy parts that 11 specified when you confirm 
        whether specific parts are survived. 
        Identifications ID of each part are allotted without the overlapping thing. 
        It has already been destroyed when identification ID is different because it is 
        reset in 0 when parts are destroyed or other parts will use the ID. 


  "GETANGLE",int1,int2,int3,int4
        Calculates the angle from A to B and returns it to _stat.

        int1    A X
        int2    A Y
        int3    B X
        int4    B Y


  "SCOS",var1,var2,int3,int4
        calculates the value of sin and cos of the specified angle.
        The value of sin and cos usually takes the range from -1.0 to 1.0. 
        The correction value is multiplied because the decimal point cannot be treated in the 
        script and returns it to var1 and var2.

        var1    Variable to return sin
        var2    Variable to return cos
        int3    Angle
        int4    Correction value



  "CREATEOBJECT",var1,int2,int3,int4,int5,int6,int7
        Create the object for draw image, word and fill box. 

        var1    Variable
        int2    Align flag (0~15)
                0       Left / Top
                &1      Center
                &2      Right
                &4      Middle
                &8      Bottom

        int3    Base Position based on window (0~8)
                ---------
                |0  1  2|
                |3  4  5|
                |6  7  8|
                ---------

        int4    Positional correction X (dot)
        int5    Positional correction Y (dot)
        int6    Frame until destroy
                >=0     Specified frame value
                -1      infinite

        int7    Fade in frame value


  "DESTROYOBJECT",int1,int2,int3,int4
        Set the destroy parameter of object.

        int1    Object ID
        int2    Frame until destroy
        int3    Fade out frame value
        int4    Fade out option
                &1      Zoom X
                &2      Zoom Y
                &4      Reduce X
                &8      Reduce Y


  "OBJECTIMAGE",int1,int2,int3,int4,int5,int6,int7,int8
        Set the object to image type.

        int1    Object ID
        int2    Image ID
        int3    X
        int4    Y
        int5    Size X
        int6    Size Y
        int7    Blend mode
        int8    Blend rate


  "OBJECTFILL",int1,int2,int3,int4,int5,int6,int7,int8
        Set the object to fill type.

        int1    Object ID
        int2    Red (0~255)
        int3    Green (0~255)
        int4    Blue (0~255)
        int5    Size X (-1:width of window)
        int6    Size Y (-1:height of window)
        int7    Blend mode
        int8    Blend rate


  "OBJECTWORD","str1",int2,int3,int4
        Set the object to fill type.
        "COLOR" and "FONT" are applied to change in the text color and the font.

        "str1"  Message
        int2    Object ID
        int3    Draw counter value
        int4    Draw option
                -1      No change
                &1      Blink
                &2      Open face
                &4      Change color
                &8      Change font


  "OBJECTPOS",int1,int2,int3,int4
        Set the object position.
        int1    Object ID
        int2    Base Position based on window (0~8)
                ---------
                |0  1  2|
                |3  4  5|
                |6  7  8|
                ---------
        int3    Positional correction X (dot)
        int4    Positional correction Y (dot)



  "LOADIMAGE","str1",int2
        Load image file.
        Loaded image and image ID is use with "OBJECTIMAGE" and "OBJECTIMAGEFONT".

        "str1"  Image file (*.bmp *.jpg *.mag)
        int2    Image ID (0~15)


  "WINDOW",int1,int2
        Change window size.
        When it gets away from a try, the window size is restored in the original size automatically.

        int1    Window size X (320~)
        int2    Window size Y (240~)


  "RANDOMIZE",int1
        Change the random number parameter.
        This parameter is used by rand().

        int1    Parameter


  "CHOICES","str1","str2","str3"...
        Create 1~8 of choices.
        This function suspends processing of a script until the choices are chosen.
        When the choices are chosen, the index is returned to _stat.
        An index is assigned in turn from 0 to each choices.

        "str1~8"  word of the choices


  "DDACCEPT",var1,var2
        Accepts drag and drop of *.fed files.
        Don't omit var1 and var2.
        Variable (var1 and var2) is initialized to STR type.
        When drag and drop succeeded, file name is substituted for var1 and enemy name is substituted for var2.
        When it succeeds once, drag and drop becomes invalid.
        When you'd like to accept drag and drop again, please reexecute function.

        var1    Variable to substitute the file name
        var2    Variable to substitute the enemy name


  "GETRANDOMFED",var1,var2,int3
        Gets the enemy file from random list.
        Don't omit var1 and var2.
        When failing, -1 is returned to _stat.
        When succeeded, file name is substituted for var1 and enemy name is substituted for var2.
        If int3 is omitted or -1, it'll be random.

        var1    Variable to substitute the file name
        var2    Variable to substitute the enemy name
        int3    Index option
                -1      Random
                >=0     Specified index


  "PLAYERDESTROYED",int1,"label2",int3
        Processing when player destroyed.
        Uses a value that returned by "ADDSUBSCRIPT" to ScriptID.
        If ScriptID is omitted or 0, that will be 0. (0=MainScript)

        int1      Processing
                  0       Game over
                  1       Clear
                  2       Jump to label (goto)
                  3       Jump to label (gosub)

        "label2"  Label name
        int3      ScriptID


  "PARTSGRAPHICS","str1",int2
        Change the parts graphics.

        "str1"    File name (*.fpg)
        int2      Option (0~3)
                0       Overwrite
                1       Initialize
                &2      Enable fade


  "PLAYERGRAPHICS","str1"
        Change the player graphics.

        "str1"    File name (*.fpl)


  "PLAYEREXTEND",int1,int2,int3,int4,int5,int6
        Extend setting.

        int1    Extend limit
                -1      No limit
                0       Invalidate
                1~      Specified

        int2    Extend score - base
        int3    Extend score - every
        int4    Extend score - add
        int5    Extend score - mul
        int6    Extend score - limit


  "GAMEOVER"
        Ends as failure.
        This can select continue,
        so please be careful about the construction of the script.


  "BGRESET"
        Reset the background params.


  "DSELOAD","str1",int2
        Load sound effect to sound buffer.
        This Function uses DirectSound.

        "str1"    File name (*.wav *.mp3)
        int2      Sound buffer ID (0~63)


  "DSEPLAY",int1,int2,int3,int4
        Play the sound buffer.
        This Function uses DirectSound.

        int1    Sound buffer ID
        int2    Volume (0~100%)
        int3    Loop flag (0~1)
        int4    Fadein frame (0~)


  "DSESTOP",int1,int2
        Stop the sound buffer.
        This Function uses DirectSound.

        int1    Sound buffer ID
        int2    Fadeout frame (0~)


  "DSEVOLUME",int1,int2,int3
        Changes the volume of sound buffer.
        This Function uses DirectSound.

        int1    Sound buffer ID
        int2    Volume (0~100%)
        int3    Fade frame (0~)


  "DSEFREQUENCY",int1,int2,int3
        Changes the frequency of sound buffer.
        This Function uses DirectSound.

        int1    Sound buffer ID
        int2    Frequency (50~44100 Hz)
        int3    Fade frame (0~)


  "DSEGETFREQUENCY",int1,int2
       Gets the frequency of sound buffer.
       The frequency returns to _stat.
        This Function uses DirectSound.

        int1    Sound buffer ID
        int2    Mode (0~1)
                0       Current frequency
                1       Source frequency


  "ADDSUBSCRIPT","label1",var2
        This function sets the sub script which is begun from a designated label.
        Sub script is execute after main script by the ID order.
        Main script is ID=0.
        The maximum number of a subscript is 15.
        When failed, negative number is returned to var2.
        When succeeded, sub script ID is returned to var2.

        A stop by "LIMIT" and "WAIT" is being managed separately respectively by main script and sub script.
        All other things(objects, variable, etc...) are shared.

        "label1"  Start point label
        var2      Variable to return a result


  "DELSUBSCRIPT",int1
        Deletes sub script.

        int1    sub script ID


  "EXISTOBJECT",var1
        Existence confirmation of an object.
        When an object of var1 doesn't exist, var1 is reset by 0.

        var1    Object ID variable


  "OBJECTIMAGEFONT",int1,int2,int3,int4,int5,int6,int7,int8
        Set the object to image font type.
        An image font uses a image for draw string.
        Use "OBJECTSTRING" for change string.
        See sample for more information.

        int1    Object ID
        int2    Image ID
        int3    Font size X (dot)
        int4    Font size Y (dot)
        int5    Shift X (dot)
        int6    Shift Y (dot)
        int7    Blend mode
        int8    Blend rate


  "OBJECTSTRING","str1",int2,int3
        Changes the string of an object.
        Use this function for "OBJECTWORD" and "OBJECTIMAGEFONT".

        "str1"  Message
        int2    Object ID
        int3    Draw counter value

  "EFFECTSCROLL",int1,int2,int3,int4
        Set a effect scroll.

        int1    Scroll speed
        int2    Fade value of scroll speed (1~)
        int3    Scroll angle (0~4095)
        int4    Fade value of scroll angle (1~)


  "SETKILLCOUNT",int1,int2,int3,int4
        Change the kill count value.
        To get the kill count (All) and (Enemy) value, use "GETINFO".
        To get the kill count (Core) value, use _killcore.
        To get the kill count (Parts) value, use _killparts.

        int1    Kill count (All)
        int2    Kill count (Enemy)
        int3    Kill count (Core)
        int4    Kill count (Parts)

        Kill count is increased when the parts are destroyed, suicided or deleted.

        (All)    Increased certainly.
        (Enemy)  Increased when the core is destroyed, suicided or deleted.
        (Core)   Increased when the condition matches a kill count flag of parts.
        (Parts)  Increased when the condition matches a kill count flag of parts.

        kill count flag : (default value: the core is 5, other parts are 4)
                &1      Increase kill count (Core) when the parts are destroyed.
                &2      Increase kill count (Core) when the parts are suicided or deleted.
                &4      Increase kill count (Parts) when the parts are destroyed.
                &8      Increase kill count (Parts) when the parts are suicided or deleted.


  "PLAYERSLOT",int1,int2
        Change the player equipment.

        int1    Target slot (0 or 1~5)
                0       Current slot
                1~5     Target slot

        int2    Equipment ID (see "PLAYERSHIP")


  "PLAYERSLOTLV",int1,int2
        Change the player slot level.

        int1    Target slot (-1 or 0 or 1~5)
                -1      All slot
                0       Current slot
                1~5     Target slot

        int2    Slot level (1~5)


  "PLAYERPOS",int1,int2
        Change the player position.
        To get the current player position, use _px and _py.

        int1    Absolute position X
        int2    Absolute position Y


  "PLAYERENERGY",int1
        Change the player energy.
        To get the current energy and maximum energy, use _penergy and _penergymax.

        int1    Energy (0~)


  "PLAYERSTOCK",int1
        Change the player energy stock.
        To get the current energy stock and maximum energy stock, use _pstock and _pstockmax.

        int1    Energy stock (0~)


  "PLAYEREMP",int1
        Change the player emp value.

        int1    Emp value (0~)


  "PLAYERBIND",int1,int2,int3
        Change the player bind value.

        int1    Bind time (0~ frame)
        int2    Bind power Move (0~100)
        int3    Bind power Turn (0~100)


  "PLAYERRESTRAINT",int1,int2
        Change the player restraint value.

        int1    Restraint time (0~ frame)
        int2    Restraint power (0~)
                0       None
                1       Active type
                &4      Bullet type
                &8      Blaster type
                &16     Support type


  "WAITFOR",int1,int2
        This function will stop the script during int2 frame if int1 is false. (false: int1=0)
        After stopping, the script executes this function again.
        If int1 is true, this function does neither a stop nor a wait. (true: int1!0)

        int1    conditional expression or value
        int2    wait frame (0~)


  "CHOICERESET",int1
        Resets the setting of "CHOICES" items.

        int1    item ID (-1 or 0~7)
                -1      All item
                0~7     Target item


  "CHOICEPOS",int1,int2,int3,int4,int5
        Sets the position of "CHOICES" item.

        int1    Item ID (0~7)
        int2    Align (0~15)
        int3    Base pos (0~7)
        int4    Pos X
        int5    Pos Y


  "CHOICEWORD",int1
        Sets the "CHOICES" item to word type.
        The item established by this function has to set position by "CHOICEPOS".

        int1    Item ID (0~7)


  "CHOICEIMAGE",int1,int2,int3,int4,int5,int6,int7,int8
        Sets the "CHOICES" item to image type.
        The item established by this function has to set position by "CHOICEPOS".

        int1    Item ID (0~7)
        int2    Image ID
        int3    Image X (dot)
        int4    Image Y (dot)
        int5    Size X (dot)
        int6    Size Y (dot)
        int7    Blend mode (3~6)
        int8    Blend rate (0~255)


  "CHOICEIMAGEFONT",int1,int2,int3,int4,int5,int6,int7,int8
        Sets the "CHOICES" item to image font type.
        The item established by this function has to set position by "CHOICEPOS".

        int1    Item ID (0~7)
        int2    Image ID
        int3    Font size X (dot)
        int4    Font size Y (dot)
        int5    Shift X (dot)
        int6    Shift Y (dot)
        int7    Blend mode
        int8    Blend rate


  "OBJECTANGLE",int1,int2
        This function is used by an image or fill type.
        Changes a object angle.

        int1    object ID
        int2    angle (~0~, 4096 = 360deg)


  "OBJECTZOOM",int1,int2,int3
        This function is used by an image or fill type.
        Changes a object zoom rate.
        Flip vertical or horizon when set a negative number.

        int1    object ID
        int2    zoom X (~512~, 512 = 1.0)
        int3    zoom Y (~512~, 512 = 1.0)


  "DEBUGMODE",int1
        Changes debug mode.
        When debug is ON, a debug menu is added to a pause menu and a try result.
        A debug log will save in to current try directory.

        int1    debug mode (-1 or 0~)
            -1      reset a debug log
            0       turn OFF debug
            1~n     turn ON debug (Specify information to record from the following value)

            &1      string of "DEBUG"
            &2      system
            &4      error
            &8      file in/out
            &16     create object, enemy, sound, etc...
            &32     setting
            &64     etc


  "DEBUG","str1"
        Write a string to a debug log.

        "str1"  string


  "SETCOOPERATIVE",int1,int2
        Changes cooperative level of script.

        int1    script ID (0~n)
        int2    cooperative level (0~1)


  "DESTROYCHOICES",int1
        Destroys the choices.
        Uses this function in a sub script which set a cooperative level to 1.

        int1    return value of choices (-n~n)


 "SETSCRIPTADDRESS","label1",int2,int3
        Changes the ProgramCounter of ScriptID like "GOTO" and "GOSUB".
        The ProgramCounter after the change is appointed with a label.

        "label"    Label
        int2      ScriptID
        int3      Mode (0~2)
            0       Goto
            1       Gosub
            &2      Clear a stack (goto only)


 "TABLEINIT",int1
        Initialize the hashtable.
        Many table slots stabilize access speed, but the output file size becomes big.

        int1      Table slot


 "TABLESAVE","str1","str2"
        Saves the hashtable.

        "str1"  File name
        "str2"  Encrypt key


 "TABLELOAD","str1","str2"
        Loads the hashtable.

        "str1"  File name
        "str2"  Encrypt key


 "TABLEADD","str1",value2
        Writes/Rewrites a value.

        "str1"  Key
        value2  Value (int,double,str)


 "TABLEREMOVE","str1"
        Deletes a value.

        "str1"  Key


 "TABLEGET","str1",var2
        Gets a value.

        "str1"  Key
        var2    Variable to receive a value


 "DISABLEREPLAY"
        Disables replay recording.


 "FCSLOAD","str1"
        Loads the custom sprite.

        "str1"  File name




-- Old functions

    Following functions has been left for compatibility. 


  "MOV",var1,int2
        Substitute int2 for var1.


  "ADD",var1,int2
        Adds int2 to var1.


  "SUB",var1,int2
        Subtracts int2 from var1.


  "MUL",var1,int2
        Multiplies int2 to var1.


  "DIV",var1,int2
        Divides var1 with int2.


  "MOD",var1,int2
        Divides var1 with int2 and substitutes the remainder to var1.

