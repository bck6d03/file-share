---------------------------
  FRAXY v.20150606beta
   English manual
                   by mon
                   http://monz.sp.land.to/
---------------------------

-- What's this?

    It's based on all the direction 2D shooting games.
    "makes as liked and destroys as liked" is a game of the concept.

    You can make a new enemy by an editor.
    Please read manual(doc/readme_edit_en.txt) and create original enemies!


-- System requirements

    Windows XP, Vista, 7
    DirectX 8 or later

    Very fast CPU for enough speed.


-- Uninstall

    This program doesn't use a registry.
    Therefore delete the extracted folder.


-- Controls

    Cursor key and mouse are used in default setting. 
    Key input can change by 'config.exe'.

             Move : Cursor key
             Turn : Mouse Cursor
          Shot/OK : Left click
     Boost/Cancel : Right click
    Weapon change : Shift key / Mouse wheel
      View change : Enter key
          Slot1~5 : 1~5

            Pause : ESC key

    Draw option can be changed by the following keys.

       Background : F2 key
        Draw type : F3 key
      Window size : F4 key
      Full screen : F5 key
     Window frame : F6 key
     Sound effect : F7 key
       Debug info : F9 key


-- Player ship

    A player ship has the main energy and uses that for any actions.
    The main energy is always recovery.

    A boost improves move speed, but the main energy recovery rate will be half.

    A player ship has an energy shield.
    The energy shield uses the main energy.
    That defends all enemy's bullets perfectly, but main energy decreases.
    When not having enough main energy in the case, a player ship would be destroyed.
    An energy shield can defend enemy's bullets only.
    So it isn't possible to defend physical damage.

    Player has 5 equip slots, and can choose from the following equipment.

  * Bullet type
             Bullet : Basic bullet.
        Wide bullet : Wide range bullet.
             Vulcan : Short range, high fire rate.
        Stun bullet : Stun bullet.
       Flash bullet : High speed or hitscan bullet.
    Ricochet bullet : Reflective bullet.
              Laser : High power laser.

  * Blaster type
            Blaster : Area attack bomb.
      Multi blaster : Launch a lot of blasters at the same time.
       Stun blaster : Stun blaster.
  Charge blaster PT : Improves fire power by energy charging.
  Charge blaster QT : Quick charge type.

  * Support type
        Over loader : Reduces the delay of equipment for a few seconds.
             Shield : Generates the shield for a few seconds.
         Blur decoy : Generates the decay for a few seconds.
      Soll diffuser : Generates the energy field that absorbs enemy bullet.
     Soll activator : Increase all equipment level for a few seconds.


-- Power up items

    When core parts beyond enemy's medium size are destroyed, a power up item appears.
    An item has the various effect. (Maximun energy up, equipment level up, etc...)
    The effect of each item isn't written here conversantly.
    Please get it in the game and check it.


-- Basic game system

    The basis only destroys the enemy.

    The enemy is composed of two or more parts.
    When the parents parts are destroyed, the child parts are destroyed in the chains.
    This chain bring about the magnification.

    When the child parts are destroyed, constant damage is given to the parents parts. 
    Even if the parents parts are destroyed by the damage, the chain is caused. 


-- Free play

    It's for practice and training.
    No penalty no matter how it is done.

       Random : The enemy is made to appear at random.
       Select : The selected enemy appears.
    Clipboard : The enemy on clipboard appear.
       Option : Free play configuration.


-- Try

    It's challenge mode with some theme.
    This mode can save replay.
    When you die once, it'll be a game over, but it can continue.
    However, a replay can't save after continue.

    Select : Select a try to play.
    Replay : Select a replay.


-- Replay

    The View can change by view change button (default:Enter key).

             Player : View of player
    Center of enemy : Center of nearby enemy
              Enemy : View of nearby enemy
               Free : Its can move by move key (Boost key can also be used together)


-- Game style

    Game balance changes by Game style.
    This option has affect on only a default bullets.

     Normal : Default
    Extreme : +33% bullet speed
        Fun : +66% bullet speed
    Danmaku : -33% bullet speed


-- Other

    Enemy file and replay file can be read by drag and drop.


-- Promise, etc

    This program is freeware.

    Even if a trouble occurs with this program and files,
    a creator does not take responsibility.
    Use at your own risk please.

    Creator 'mon' holds the copyright of this program.

    About redistribution, remodeling and others.
    Unless these program and files are abused, you may assume that you obtained creator's permit.

    There may be a strange expression
    because I depend on machine translation for English version.
    When you found a strange translation part,
    please laugh and overlook by all means.

    Thank you for download this game and reading.

