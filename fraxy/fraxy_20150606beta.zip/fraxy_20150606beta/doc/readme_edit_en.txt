---------------------------
  FRAXY Enemy editor
    English manual
                   by mon
---------------------------

-- How to use

    When [Add parts] of {Parts list} is pushed when there is nothing,
    a core would be generated.

    Freely add parts after generating the core,
    input each parameter, and compose the enemy. 

    Input the enemy name to {Parts list},
    and preserve it with the save button of 'Tool' when completing it. 

    Please refer to the enemy prepared by default.


-- Specification etc

    The direction is round 4096 clockwise.

    A positional setting is difficult.
    The point to have moved only the base point angle and the distance 
    from the parents parts is made a base point. 
    A center distance moves center points of parts.

    The number of child parts applied to parts is up to 16. 
    Child parts of the child parts are not contained.

    It is possible to delay it only by the frame by specifying the minus 
    for the beginning frame of the move and the attack action. 
    It is effective to execute the operation of the separation etc.

    More than one action may exist by parts.
    The different pattern can use by changing the starting action.

    When core parts are used as child parts, it doesn't move.
    But when parent parts were destroyed, it will detach and begins to move as new core parts.
    But the detach by the destruction gives damage to new core parts.
    If the durability disappears by the damage, core parts would be destroyed.


-- Control and explanation

    {Tool}
        This window does the control of each window and reads and writes the file.

      file
        [save]        The made enemy data written file.
                          all : All information is written.
                      minimum : Omissible data is omitted and written.

        [load]        The enemy data is read from the file.

      view
        [center]      Return to center the view of {Edit window}.
        [free]        Free view.
        [core]        The view is set in a core. (ID:1)
        [select]      The view is set in selective parts.

      option
        [info]        The infomation is displayed in {Edit window}.
        [grid]        The grid is displayed in {Edit window}.
        [arrow]       The arrow and protractor is displayed in {Edit window}.
        [box]         The box is displayed in {Edit window}.
        [mouse]       Mouse coordinates and cross line are displayed in {Edit window}.
        [ID]          ID of parts of a cursor are displayed in {Edit window}.
        [target]      The target marker is displayed in {Edit window}.
        [hitchk]      The target marker hits enemy's bullet.
        [hitbox]      The hitbox is displayed in {Edit window}.
        [alpha]       Changes the draw type in {Edit window}.
        [invisi]      Hidden parts is displayed in {Edit window}.
        [SE]          ON/OFF the sounds.

      object
        [play]        Play the enemy in {Edit window}.
        [stop]        Stop the enemy in {Edit window}.
        [reset]       Enemy's operation and position are initialized in {Edit window}.
        [wait]        Adjust the speed of preview in {Edit window}.

        [1~100]       Input the frame value of play.
        [frame]       Play only the input frame value.

      rank
        [1~100]       Input the enemy rank.
        [change]      Set the input enemy rank.

      window
        [misc]        Show/Hide {Misc window}.
        [fix]         Remove a frame from some windows.


    {Edit window}
        This window does the edit information display and the enemy.
        It is possible to operate it as follows.

        Left click       Select the parts.
        Left drag        Move the parts.
        Left drag+Shift  Change the parts angle.
        Right click      Popup the Parts operation menu.
        Right drag       Move the view.

        Move key         Move the target marker position.
        B key            Move the target marker with boost.
        T key            Set the target marker position.
        PageUp/Down      Scroll the action infomation.

        When a grid and an arrow are on, the following control button is shown to the bottom.
        The parameter of each function can be changed by these buttons.

        [GRID]           Change grid size
        [ARROW]          Change arrow size
        [PROTRACTOR]     Change division of protractor
        [BOX]            Change box size
        [INFO SCROLL]    Change scroll position of infomation

        Parts that have been selected are enclosed with a green frame,
        and when it is possible to move with a left drag, become blue. 

        Not smoothly moving when parts move
        It is because angling the check is attached to "Angles fixed in 32 directions"
        of the option and the limitation is put.

        When a mouse cursol in Edit window, the target position can be changed by a T key.


    {Parts list}
        This window manages parts.
        Composition information on parts is indicated like a tree.

        Name:[ ]        Enter the enemy name.
        Appear:[ ]      Enemy's appearance method.
                        Simultaneous : All parts appear simultaneously.
                         Index order : Appear by order of the ID.
                        Parent order : Appear by parent order.
                            (adjust) : Time until the appearance is considered,
                                       and the starting frame value is corrected automatically.

        [Add parts]     Make new parts to selective parts.
        [Del parts]     Delete the selective parts and the all child parts.
        [Appear chk]    Preview the effect of appearing.
        [Destroy chk]   Preview the effect of destroying from selective parts.
        [Copy]          Copy to a clipboard the selective parts and the all child parts.
        [Paste]         Paste to selective parts from a clipboard.
        [Paste (turn)]  Paste to selective parts from a clipboard with reversed.
        [Repair]        Restore damage. (if parts is not destroyed)
        [1%damage]      1% damage to selective parts.
        [10%damage]     10% damage to selective parts.


    {Core info} / {Parts info}
        This window inputs a parameter of parts.

        Parts         Select from registered parts.
                      The left number with a parts name indicates the default durability.
                      Parts are classified into the following kind.
                      [A] Attack    Parts with the attack action
                      [B] Brick     Brick parts (no action parts)
                      [C] Core      Core parts
                      [D] Defense   Parts for decoration (no action parts)
                      [E] Effector  Parts for visual effect generation
                      [J] Joint     Parts with the move action

        Draw order    Select the draw order of parts.

        Draw flag     Select the draw flag.
                      (-1) Hide    hidden without collision
                      (0)  Normal  shown with collision
                      (1)  Shadow  shown darkly without collision

        Movement      Select the movement flag.
                      (0) Stop    Stop all action (It will be like [D] parts.)
                      (1) Play    Play all action

        Turn flag     Select the turn flag.
                      (0)None        None
                      (1)Draw        Reversed drawing

        Connection    Select the connection type.
                      (0)Fix           Fixed on a parent
                      (1)Tail          Moves like a tail
                      (2)Player        Player is assumed with parent.
                      (3)Player(pos)   Player is assumed with parent. (position only)
                      (4)Alone         Stops at the place.
                      (5)Re-fixing     Follows parent and it's fixed finally.
                      (6)Harf-fixing   Follows parent.
                      (7)Tali-Re-fix   Moves like a tail and it's fixed finally.
                      (8)Player(axis)  Moves only on the axis of parent and follow player.
                      (9)Midpoint      Moves to middle of parent and pointer.
                      (10)Pointer      Follows pointer.

        Durability    Input the durability of parts.
                      If being omitted or 0, the default durability would be used.
                      When a minus is designated, it isn't destroyed by a player any more.

        Score         Input the score of parts.

        (Core info)

            Init angle    Set the initial angle of enemy.

            Direction     Set the direction of appearance position.

            Distance      Set the distance of appearance position.

        (Parts info)

            Parts angle   Set the angle of parts.
                          It can be set by a circle slider.
                          +ctrl : Reverses a option (Angles fixed in 32 directions).
                          +shift : Angles fixed in 24 directions.

            Center dist   Set the distance of central point of parts.

            BP angle      Set the angle of base point.
                          It can be set by a circle slider.
                          +ctrl : Reverses a option (Angles fixed in 32 directions).
                          +shift : Angles fixed in 24 directions.

            BP dist       Set the distance from center of parent parts.


        [Mov act:**]:[]: Starts Mov frame
                      Set the beginning move action and beginning move frame.
                      The setting becomes effective by [reset].

        [Att act:**]:[]: Starts Att frame
                      Set the beginning attack action and beginning attack frame.
                      The setting becomes effective by [reset].


    {Event}
        Set event to parts.
        Event can be set up to 16 per one part.
        Event is executed from the top.

        [Add]         Add new event
        [Del]         Delete selective event
        [Dup]         Duplicate selective event
        [Up]          Move up selective event
        [Down]        Move down selective event
        [Template]    Open event template menu

        Condition
                      Set a condition and a method to execute the event.
                      Conditions can be set up to three in the form of the expression.

                      [AND]    If condition is all true, execute event.
                      [OR]     If one or more is true, execute event.

        Action
                      Set the action of the event. 
                      4 actions can be set to one event.

        After execution
                      Set the processing after the event. 


    {Option}
        Change the options.

        [ ] Angles fixed in 32 directions
                      When setting the angle, one round is made 32 direction (every 128).

        [ ] Parts tree labels matched to the part name
                      The tree label of {Parts list} is changed to a selected parts name.

        [ ] Center Dist automatic substitution
                      When the parts was changed,
                      input the default value to center dist automatically.

        [ ] Draw order automatic substitution
                      When the parts was changed,
                      input the default setting to draw order automatically.

        [ ] Durability automatic substitution
                      When the parts was changed,
                      input the default value to durability automatically.

        [ ] Enable wheel to change a numerical parameter
                      Enables wheel control for input box.


    {Misc window}
        This window has the function which isn't used so much.

        Note
                      Notepad.
                      This note are written in the enemy file.

        Sprite
                      A list of the sprite which can be designated by sprite change in the effector (Ex1 &8,Ex5~12).

        Sound
                      A list of the sound which can be designated by sound change in the sound effector (Ex1).

        Player
                      This can change the player status to check events.

        Info option
                      This changes the type of information for edit window.

        Color
                      This changes the color of background, bullet, etc...

        Fade type
                      This is a list of fade type for extra parameters.

        Scroll
                      This changes the scroll speed and direction.

        Calc
                      Calculator.
                      The math function of try script can be used in math expression.

