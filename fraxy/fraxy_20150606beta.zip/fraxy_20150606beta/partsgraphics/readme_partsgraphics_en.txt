// Please put a parts graphics file(*.fpg) in this folder.

// The explanation about *.fpg file.
// It's possible to omit the function which has no notations.

"FRAXY_PARTSGRAPHICS","str1"
	Define of fpg file.
	*Don't omit this function.
	*Be sure to describe first.
	*Describe "FRAXY_PARTSGRAPHICS" by uppercase.
	"str1" : Name of setting

"blendmode",int1
	Setting of blend mode.
	int1 : Blend mode
		4 : Translucent (default)
		5 : Addition
		6 : Subtraction

"blendrate",int1
	Setting of blend rate.
	int1 : Blend rate (0~255, 0=0%, 255=100%)

"base","str1"
	Setting of a basic image file.
	*Don't omit this function.�ibut, when overwriting by a try, you can omit�j
	"str1" : filename (*.bmp)

"damage","str1"
"phase","str1"
"shadow","str1"
	Setting of a image file for each condition.
	When omitting, it's generated automatically. (but, when overwriting by a try, it isn't generated automatically)
	"str1" : filename (*.bmp)











