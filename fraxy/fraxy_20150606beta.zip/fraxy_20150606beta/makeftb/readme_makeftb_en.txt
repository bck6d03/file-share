---------------------------
  FRAXY MakeFTB
                   by mon
---------------------------

-- What this?

    This tool can easily make FTB by drag and drop.
    Please make FTB after check by fraxy.exe.


-- How to use

    1. Drag and drop FTD file. (any extension can use input file)

    2. Press "Compile".

    3. Done.


-- Use command line

        ex) MakeFTB "filename"

        Output directory is same as input.
        Any extension can use input file.

